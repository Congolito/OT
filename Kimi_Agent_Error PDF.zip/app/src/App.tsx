import { useState, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Printer, FileText, RotateCcw, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import './App.css';

interface Tecnico {
  nombre: string;
  empleado: string;
  hh: string;
}

interface OTData {
  equipo: string;
  area: string;
  horometro: string;
  otNo: string;
  fechaInicio: string;
  horaInicio: string;
  fechaFinal: string;
  horaFinal: string;
  turno: string;
  supervisor: string;
  problemGroup: string;
  problem: string;
  cause: string;
  descripcion: string;
  pendientes: string;
  cerrarTarea: 'SI' | 'NO' | '';
  tecnicos: Tecnico[];
}

const initialTecnicos: Tecnico[] = Array(5).fill(null).map(() => ({ nombre: '', empleado: '', hh: '' }));

const initialData: OTData = {
  equipo: '',
  area: '',
  horometro: '',
  otNo: '',
  fechaInicio: '',
  horaInicio: '',
  fechaFinal: '',
  horaFinal: '',
  turno: '',
  supervisor: '',
  problemGroup: '',
  problem: '',
  cause: '',
  descripcion: '',
  pendientes: '',
  cerrarTarea: '',
  tecnicos: initialTecnicos,
};

// Declaración de tipos para librerías globales
declare global {
  interface Window {
    html2canvas: (element: HTMLElement, options?: Record<string, unknown>) => Promise<HTMLCanvasElement>;
    jspdf: {
      jsPDF: new (orientation: string, unit: string, format: string) => {
        internal: { pageSize: { getWidth: () => number; getHeight: () => number } };
        addImage: (imageData: string, format: string, x: number, y: number, width: number, height: number) => void;
        save: (filename: string) => void;
      };
    };
  }
}

function App() {
  const [data, setData] = useState<OTData>(initialData);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);

  const handleInputChange = (field: keyof OTData, value: string) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const handleTecnicoChange = (index: number, field: keyof Tecnico, value: string) => {
    setData(prev => {
      const newTecnicos = [...prev.tecnicos];
      newTecnicos[index] = { ...newTecnicos[index], [field]: value };
      return { ...prev, tecnicos: newTecnicos };
    });
  };

  const calcularTotalHoras = useCallback(() => {
    return data.tecnicos.reduce((total, t) => {
      const hh = parseFloat(t.hh) || 0;
      return total + hh;
    }, 0);
  }, [data.tecnicos]);

  const handlePrintPDF = async () => {
    if (!formRef.current) return;
    
    setIsGeneratingPDF(true);
    toast.info('Generando PDF...', { duration: 2000 });
    
    try {
      // Verificar que las librerías estén cargadas
      if (typeof window.html2canvas === 'undefined') {
        throw new Error('html2canvas no está cargado. Por favor recarga la página.');
      }
      if (typeof window.jspdf === 'undefined' || !window.jspdf.jsPDF) {
        throw new Error('jsPDF no está cargado. Por favor recarga la página.');
      }
      
      const element = formRef.current;
      
      const canvas = await window.html2canvas(element, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
        width: element.offsetWidth,
        height: element.offsetHeight,
      });
      
      const imgData = canvas.toDataURL('image/png');
      
      // Crear PDF en formato A4
      const pdf = new window.jspdf.jsPDF('p', 'mm', 'a4');
      
      const pdfWidth = 210;
      const pdfHeight = 297;
      const margin = 10;
      
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      
      const availableWidth = pdfWidth - (margin * 2);
      const availableHeight = pdfHeight - (margin * 2);
      
      const scaleX = availableWidth / (imgWidth * 0.264583);
      const scaleY = availableHeight / (imgHeight * 0.264583);
      const scale = Math.min(scaleX, scaleY, 1);
      
      const finalWidth = imgWidth * 0.264583 * scale;
      const finalHeight = imgHeight * 0.264583 * scale;
      
      const x = (pdfWidth - finalWidth) / 2;
      const y = margin;
      
      pdf.addImage(imgData, 'PNG', x, y, finalWidth, finalHeight);
      
      const otNo = data.otNo || 'sin_numero';
      const fecha = new Date().toISOString().split('T')[0];
      
      pdf.save(`OT_${otNo}_${fecha}.pdf`);
      toast.success('PDF generado correctamente');
    } catch (error) {
      console.error('Error generando PDF:', error);
      toast.error('Error al generar PDF: ' + (error instanceof Error ? error.message : 'Error desconocido'));
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleReset = () => {
    if (confirm('¿Está seguro de limpiar todos los campos?')) {
      setData(initialData);
      toast.success('Formulario limpiado');
    }
  };

  const formatDateTime = (date: string, time: string) => {
    if (!date && !time) return '-';
    if (date && !time) return date;
    if (!date && time) return time;
    return `${date} ${time}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
      {/* Header con acciones - No se imprime */}
      <div className="max-w-5xl mx-auto mb-6 print:hidden">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-slate-800 flex items-center gap-3">
              <FileText className="w-8 h-8 text-blue-600" />
              Orden de Trabajo
            </h1>
            <p className="text-slate-500 mt-1">Sistema de gestión de órdenes de trabajo</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button 
              onClick={handlePrintPDF} 
              disabled={isGeneratingPDF}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isGeneratingPDF ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Printer className="w-4 h-4 mr-2" />
              )}
              {isGeneratingPDF ? 'Generando...' : 'Guardar PDF'}
            </Button>
            <Button 
              onClick={handlePrint}
              variant="outline"
              className="border-slate-300"
            >
              <Printer className="w-4 h-4 mr-2" />
              Imprimir
            </Button>
            <Button 
              onClick={handleReset}
              variant="outline"
              className="border-red-300 text-red-600 hover:bg-red-50"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Limpiar
            </Button>
          </div>
        </div>
      </div>

      {/* Formulario editable - No se imprime */}
      <div className="max-w-5xl mx-auto print:hidden">
        <Card className="shadow-xl border-0">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
            <CardTitle className="text-xl md:text-2xl text-center">
              ORDEN DE TRABAJO
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 md:p-6">
            {/* Sección 1: Información General */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="space-y-2">
                <Label htmlFor="equipo" className="text-slate-700 font-semibold">Equipo</Label>
                <Input
                  id="equipo"
                  value={data.equipo}
                  onChange={(e) => handleInputChange('equipo', e.target.value)}
                  placeholder="Nombre del equipo"
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="area" className="text-slate-700 font-semibold">Área</Label>
                <Input
                  id="area"
                  value={data.area}
                  onChange={(e) => handleInputChange('area', e.target.value)}
                  placeholder="Área de trabajo"
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="horometro" className="text-slate-700 font-semibold">Horómetro</Label>
                <Input
                  id="horometro"
                  value={data.horometro}
                  onChange={(e) => handleInputChange('horometro', e.target.value)}
                  placeholder="Horómetro"
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="otNo" className="text-slate-700 font-semibold">OT No</Label>
                <Input
                  id="otNo"
                  value={data.otNo}
                  onChange={(e) => handleInputChange('otNo', e.target.value)}
                  placeholder="Número de OT"
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
            </div>

            {/* Sección 2: Fechas y Turno */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="space-y-2">
                <Label className="text-slate-700 font-semibold">Fecha Inicio</Label>
                <Input
                  type="date"
                  value={data.fechaInicio}
                  onChange={(e) => handleInputChange('fechaInicio', e.target.value)}
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-700 font-semibold">Hora Inicio</Label>
                <Input
                  type="time"
                  value={data.horaInicio}
                  onChange={(e) => handleInputChange('horaInicio', e.target.value)}
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-700 font-semibold">Fecha Final</Label>
                <Input
                  type="date"
                  value={data.fechaFinal}
                  onChange={(e) => handleInputChange('fechaFinal', e.target.value)}
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-slate-700 font-semibold">Hora Final</Label>
                <Input
                  type="time"
                  value={data.horaFinal}
                  onChange={(e) => handleInputChange('horaFinal', e.target.value)}
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="space-y-2">
                <Label htmlFor="turno" className="text-slate-700 font-semibold">Turno</Label>
                <Input
                  id="turno"
                  value={data.turno}
                  onChange={(e) => handleInputChange('turno', e.target.value)}
                  placeholder="Turno de trabajo"
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="supervisor" className="text-slate-700 font-semibold">Nombre Supervisor</Label>
                <Input
                  id="supervisor"
                  value={data.supervisor}
                  onChange={(e) => handleInputChange('supervisor', e.target.value)}
                  placeholder="Nombre del supervisor"
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
            </div>

            <Separator className="my-6" />

            {/* Sección 3: Clasificación del Problema */}
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                <Badge variant="secondary" className="bg-amber-100 text-amber-700">Clasificación</Badge>
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="problemGroup" className="text-slate-700 font-semibold">Problem Group</Label>
                  <Input
                    id="problemGroup"
                    value={data.problemGroup}
                    onChange={(e) => handleInputChange('problemGroup', e.target.value)}
                    placeholder="Grupo del problema"
                    className="border-slate-300 focus:border-blue-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="problem" className="text-slate-700 font-semibold">Problem</Label>
                  <Input
                    id="problem"
                    value={data.problem}
                    onChange={(e) => handleInputChange('problem', e.target.value)}
                    placeholder="Problema identificado"
                    className="border-slate-300 focus:border-blue-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cause" className="text-slate-700 font-semibold">Cause</Label>
                  <Input
                    id="cause"
                    value={data.cause}
                    onChange={(e) => handleInputChange('cause', e.target.value)}
                    placeholder="Causa raíz"
                    className="border-slate-300 focus:border-blue-500"
                  />
                </div>
              </div>
            </div>

            <Separator className="my-6" />

            {/* Sección 4: Descripción y Pendientes */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <Label htmlFor="descripcion" className="text-slate-700 font-semibold">
                  Descripción del Trabajo Efectuado
                </Label>
                <Textarea
                  id="descripcion"
                  value={data.descripcion}
                  onChange={(e) => handleInputChange('descripcion', e.target.value)}
                  placeholder="Diligencie la OT siguiendo los pasos descritos..."
                  className="min-h-[120px] border-slate-300 focus:border-blue-500 resize-none"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pendientes" className="text-slate-700 font-semibold">Pendientes</Label>
                <Textarea
                  id="pendientes"
                  value={data.pendientes}
                  onChange={(e) => handleInputChange('pendientes', e.target.value)}
                  placeholder="Actividades pendientes..."
                  className="min-h-[120px] border-slate-300 focus:border-blue-500 resize-none"
                />
              </div>
            </div>

            {/* Sección 5: Cerrar Tarea */}
            <div className="mb-6">
              <Label className="text-slate-700 font-semibold mb-3 block">CERRAR TAREA</Label>
              <div className="flex gap-4">
                <Button
                  type="button"
                  onClick={() => handleInputChange('cerrarTarea', 'SI')}
                  variant={data.cerrarTarea === 'SI' ? 'default' : 'outline'}
                  className={`flex items-center gap-2 ${
                    data.cerrarTarea === 'SI' 
                      ? 'bg-green-600 hover:bg-green-700 text-white' 
                      : 'border-slate-300 hover:bg-green-50'
                  }`}
                >
                  <CheckCircle className="w-4 h-4" />
                  SI
                </Button>
                <Button
                  type="button"
                  onClick={() => handleInputChange('cerrarTarea', 'NO')}
                  variant={data.cerrarTarea === 'NO' ? 'default' : 'outline'}
                  className={`flex items-center gap-2 ${
                    data.cerrarTarea === 'NO' 
                      ? 'bg-red-600 hover:bg-red-700 text-white' 
                      : 'border-slate-300 hover:bg-red-50'
                  }`}
                >
                  <XCircle className="w-4 h-4" />
                  NO
                </Button>
              </div>
            </div>

            <Separator className="my-6" />

            {/* Sección 6: Tabla de Técnicos */}
            <div className="mb-6">
              <h3 className="text-lg font-bold text-slate-800 mb-4">NOMBRE TÉCNICOS</h3>
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-slate-100">
                      <th className="border border-slate-300 px-4 py-3 text-left text-slate-700 font-semibold">Nombre Técnico</th>
                      <th className="border border-slate-300 px-4 py-3 text-left text-slate-700 font-semibold w-32"># Empleado</th>
                      <th className="border border-slate-300 px-4 py-3 text-left text-slate-700 font-semibold w-24">H.H</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.tecnicos.map((tecnico, index) => (
                      <tr key={index} className="hover:bg-slate-50">
                        <td className="border border-slate-300 p-2">
                          <Input
                            value={tecnico.nombre}
                            onChange={(e) => handleTecnicoChange(index, 'nombre', e.target.value)}
                            placeholder={`Técnico ${index + 1}`}
                            className="border-0 focus:ring-0 bg-transparent"
                          />
                        </td>
                        <td className="border border-slate-300 p-2">
                          <Input
                            value={tecnico.empleado}
                            onChange={(e) => handleTecnicoChange(index, 'empleado', e.target.value)}
                            placeholder="#"
                            className="border-0 focus:ring-0 bg-transparent"
                          />
                        </td>
                        <td className="border border-slate-300 p-2">
                          <Input
                            value={tecnico.hh}
                            onChange={(e) => handleTecnicoChange(index, 'hh', e.target.value)}
                            placeholder="0.0"
                            type="number"
                            step="0.5"
                            className="border-0 focus:ring-0 bg-transparent"
                          />
                        </td>
                      </tr>
                    ))}
                    <tr className="bg-slate-100 font-bold">
                      <td colSpan={2} className="border border-slate-300 px-4 py-3 text-right text-slate-700">
                        HORAS HOMBRE TOTALES
                      </td>
                      <td className="border border-slate-300 px-4 py-3 text-slate-700">
                        {calcularTotalHoras().toFixed(1)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Vista de impresión/PDF */}
      <div ref={formRef} className="hidden print:block max-w-[210mm] mx-auto bg-white">
        <div className="p-8">
          {/* Header */}
          <div className="text-center mb-6 border-b-2 border-black pb-4">
            <h1 className="text-2xl font-bold text-black">ORDEN DE TRABAJO</h1>
          </div>

          {/* Información General */}
          <div className="grid grid-cols-4 gap-2 mb-4 text-sm">
            <div className="border border-black p-2">
              <span className="font-bold block text-xs">Equipo:</span>
              <span>{data.equipo || '-'}</span>
            </div>
            <div className="border border-black p-2">
              <span className="font-bold block text-xs">Área:</span>
              <span>{data.area || '-'}</span>
            </div>
            <div className="border border-black p-2">
              <span className="font-bold block text-xs">Horómetro:</span>
              <span>{data.horometro || '-'}</span>
            </div>
            <div className="border border-black p-2">
              <span className="font-bold block text-xs">OT No:</span>
              <span>{data.otNo || '-'}</span>
            </div>
          </div>

          {/* Fechas */}
          <div className="grid grid-cols-4 gap-2 mb-4 text-sm">
            <div className="border border-black p-2">
              <span className="font-bold block text-xs">Fecha/Hora Inicio:</span>
              <span>{formatDateTime(data.fechaInicio, data.horaInicio)}</span>
            </div>
            <div className="border border-black p-2">
              <span className="font-bold block text-xs">Fecha/Hora Final:</span>
              <span>{formatDateTime(data.fechaFinal, data.horaFinal)}</span>
            </div>
            <div className="border border-black p-2">
              <span className="font-bold block text-xs">Turno:</span>
              <span>{data.turno || '-'}</span>
            </div>
            <div className="border border-black p-2">
              <span className="font-bold block text-xs">Supervisor:</span>
              <span>{data.supervisor || '-'}</span>
            </div>
          </div>

          {/* Clasificación */}
          <div className="mb-4">
            <div className="grid grid-cols-3 gap-2 text-sm">
              <div className="border border-black p-2">
                <span className="font-bold block text-xs">Problem Group:</span>
                <span>{data.problemGroup || '-'}</span>
              </div>
              <div className="border border-black p-2">
                <span className="font-bold block text-xs">Problem:</span>
                <span>{data.problem || '-'}</span>
              </div>
              <div className="border border-black p-2">
                <span className="font-bold block text-xs">Cause:</span>
                <span>{data.cause || '-'}</span>
              </div>
            </div>
          </div>

          {/* Descripción y Pendientes */}
          <div className="grid grid-cols-2 gap-2 mb-4">
            <div className="border border-black p-3 min-h-[100px]">
              <span className="font-bold block text-xs mb-1">Descripción del Trabajo Efectuado:</span>
              <span className="text-sm whitespace-pre-wrap">{data.descripcion || '-'}</span>
            </div>
            <div className="border border-black p-3 min-h-[100px]">
              <span className="font-bold block text-xs mb-1">Pendientes:</span>
              <span className="text-sm whitespace-pre-wrap">{data.pendientes || '-'}</span>
            </div>
          </div>

          {/* Cerrar Tarea */}
          <div className="mb-4">
            <span className="font-bold text-sm mr-4">CERRAR TAREA:</span>
            <span className="text-sm">
              [ {data.cerrarTarea === 'SI' ? 'X' : ' '} ] SI &nbsp;&nbsp;
              [ {data.cerrarTarea === 'NO' ? 'X' : ' '} ] NO
            </span>
          </div>

          {/* Tabla de Técnicos */}
          <div className="mb-4">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr>
                  <th className="border border-black px-3 py-2 text-left font-bold bg-gray-100">NOMBRE TÉCNICOS</th>
                  <th className="border border-black px-3 py-2 text-left font-bold bg-gray-100 w-28"># EMPLEADO</th>
                  <th className="border border-black px-3 py-2 text-left font-bold bg-gray-100 w-20">H.H</th>
                </tr>
              </thead>
              <tbody>
                {data.tecnicos.map((tecnico, index) => (
                  <tr key={index}>
                    <td className="border border-black px-3 py-2">{tecnico.nombre || '-'}</td>
                    <td className="border border-black px-3 py-2">{tecnico.empleado || '-'}</td>
                    <td className="border border-black px-3 py-2">{tecnico.hh || '-'}</td>
                  </tr>
                ))}
                <tr className="bg-gray-100 font-bold">
                  <td colSpan={2} className="border border-black px-3 py-2 text-right">
                    HORAS HOMBRE TOTALES
                  </td>
                  <td className="border border-black px-3 py-2">
                    {calcularTotalHoras().toFixed(1)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Footer */}
          <div className="mt-8 pt-4 border-t border-black text-center text-xs text-gray-500">
            <p>Orden de Trabajo - Generado el {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()}</p>
          </div>
        </div>
      </div>

      {/* Footer móvil - Solo visible en móvil */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 p-4 md:hidden print:hidden z-50">
        <div className="flex gap-2">
          <Button 
            onClick={handlePrintPDF} 
            disabled={isGeneratingPDF}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
          >
            {isGeneratingPDF ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Printer className="w-4 h-4 mr-2" />
            )}
            {isGeneratingPDF ? '...' : 'PDF'}
          </Button>
          <Button 
            onClick={handlePrint}
            variant="outline"
            className="flex-1 border-slate-300"
          >
            <Printer className="w-4 h-4 mr-2" />
            Imprimir
          </Button>
        </div>
      </div>

      {/* Espacio para el footer fijo en móvil */}
      <div className="h-20 md:hidden print:hidden"></div>
    </div>
  );
}

export default App;
